1.在config文件夹下，配置Config.json文件，将其中"http_sever_host" 项改为本机ip，"http_sever_port" 项自定义
2.
windows下直接运行exe，然后依照postman示例向对应端口发送请求
linux下运行start.sh脚本，然后依照postman示例向对应端口发送请求