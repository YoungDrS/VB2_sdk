#!/bin/bash
rm -rf build/ devel/
catkin_make
source devel/setup.bash

