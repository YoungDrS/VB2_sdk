#!/bin/bash
source devel/setup.bash
rostopic echo /lx_camera_node/LxCamera_Obstacle
